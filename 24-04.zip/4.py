ali = {"Toshkent", "Samarqand", "Buxoro", "Andijon"}
vali = {"Toshkent", "Farg'ona", "Buxoro", "Xiva"}
ikkalasi = ali & vali
faqat_ali = ali - vali
print("ikkalasi ham bor:", ikkalasi)
print("faqat Ali da bor:", faqat_ali)