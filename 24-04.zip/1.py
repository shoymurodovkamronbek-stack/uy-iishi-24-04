soz1 = "listen"
soz2 = "silent"
print(sorted(soz1) == sorted(soz2))