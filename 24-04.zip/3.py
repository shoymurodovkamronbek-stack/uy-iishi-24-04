set1 = {1, 2, 3, 4, 5, 6}
set2 = {4, 5, 6, 7, 8, 9, 10}
result = set1 ^ set2 
print(sorted(result, reverse=True))