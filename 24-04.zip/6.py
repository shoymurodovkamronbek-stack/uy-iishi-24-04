set1 = {4,5,6,7,8,9}
set2 = {5,6,7,10,11}
umumiy = sum(set1 & set2)
farqi = sum(set1 ^ set2)
print(farqi - umumiy)