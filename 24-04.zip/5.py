import os
os.system("cls")
set1 = {1, 2, 3, 4, 5, 6}
set2 = {4, 5, 6, 7, 8, 9, 10}
umumiy = sum(set1 & set2)
faqat1 = sum(set1 - set2)
print(umumiy- faqat1)